package com.example.myapplication;

import android.graphics.Bitmap;

public class Student {

    String Id,Name,Phone,Email,Password;
    Bitmap bitmap;

    public Student(String id, String name, String phone, String email, String password,Bitmap  bitmap) {
        Id = id;
        Name = name;
        Phone = phone;
        Email = email;
        Password = password;
        this.bitmap=bitmap;

    }
}
